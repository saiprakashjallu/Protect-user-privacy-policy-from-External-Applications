
from tkinter import messagebox
from tkinter import *
from tkinter import simpledialog
import tkinter
from tkinter import filedialog
from tkinter.filedialog import askopenfilename
import numpy as np
import pandas as pd
from sklearn.semi_supervised import LabelSpreading
from sklearn.metrics import accuracy_score
from numpy.linalg import norm
from numpy import dot
import matplotlib.pyplot as plt

main = tkinter.Tk()
main.title("Privacy-aware Personal Data Storage (P-PDS): Learning how to Protect User Privacy from External Applications") #designing main screen
main.geometry("1300x1200")


global filename
global sse_acc
global phbal_acc
global balance_data
global X
global Y
global unlabel_X
global y_train
global unlabel
global all_data

global X1
global Y1
global y_train1

def uploadLabelData():
    global filename
    global balance_data
    global X
    global X1
    global Y
    global Y1
    filename = filedialog.askopenfilename(initialdir = "dataset")
    balance_data = pd.read_csv(filename)
    X = balance_data.values[:, 2:4] 
    Y = balance_data.values[:, 6]
    Y = Y.astype('int')

    balance_data = pd.read_csv(filename)
    X1 = balance_data.values[:, 2:4] 
    Y1 = balance_data.values[:, 6]
    Y1 = Y1.astype('int')
    
    text.delete('1.0', END)
    text.insert(END,filename+' loaded\n')
    text.insert(END,"Labelled Dataset Size : "+str(len(balance_data))+"\n")


def uploadUnlabelData():
    global unlabel_X
    global unlabel
    global all_data
    filename = filedialog.askopenfilename(initialdir = "dataset")
    unlabel = pd.read_csv(filename)
    all_data = unlabel.values[:, 0:6]
    unlabel_X = unlabel.values[:, 2:4]
    text.insert(END,filename+' loaded\n')
    text.insert(END,"Unlabelled Dataset Size : "+str(len(unlabel_X))+"\n")

def SSE():
    global sse_acc
    global y_train
    for i in range(len(unlabel_X)):
        X[i] = unlabel_X[i]
    y_train = np.copy(Y)
    y_train[len(unlabel_X)-1] = -1
    unl = np.arange(len(unlabel_X))

    lp_model = LabelSpreading(kernel='knn', alpha=0.9)
    lp_model.fit(X, y_train)
    predicted_labels = lp_model.transduction_[unl]
    true_labels = Y[unl]
    text.delete('1.0', END)

    sse_acc = accuracy_score(predicted_labels,true_labels)*100
    for i in range(len(true_labels)):
        if true_labels[i] == 0:
            text.insert(END,str(all_data[i])+ ' Label Predicted as YES\n\n')
        if true_labels[i] == 1:
            text.insert(END,str(all_data[i])+ ' Label Predicted as NO\n\n')
        if true_labels[i] == 0:
            text.insert(END,str(all_data[i])+ ' Label Predicted as MAY BE\n\n')
            
    text.insert(END,"SSE Accuracy : "+str(sse_acc))

def getWeight(X,unlabel):
    accuracy = 0
    index = 0
    for i in range(len(X)):
        vector1 = np.asarray(X[i])
        vector2 = np.asarray(unlabel)
        acc = dot(vector1, vector2)/(norm(vector1)*norm(vector2))
        if acc > accuracy:
            index = i
            accuracy = acc
    return index,accuracy        

def PHBAL():
    global phbal_acc
    global y_train1
    text.delete('1.0', END)
    for i in range(len(unlabel_X)):
        index,acc = getWeight(X,unlabel_X[i])
        if acc > 0.90:
            X1[i] = unlabel_X[i]
    y_train1 = np.copy(Y1)
    y_train1[len(unlabel_X)-1] = -1
    unl = np.arange(len(unlabel_X))

    lp_model = LabelSpreading(gamma=.25, max_iter=20)
    lp_model.fit(X1, y_train1)
    predicted_labels = lp_model.transduction_[unl]
    true_labels = Y1[unl]
    text.delete('1.0', END)

    phbal_acc = accuracy_score(predicted_labels,true_labels)*100
    for i in range(len(true_labels)):
        if true_labels[i] == 0:
            text.insert(END,str(all_data[i])+ ' Label Predicted as YES\n\n')
        if true_labels[i] == 1:
            text.insert(END,str(all_data[i])+ ' Label Predicted as NO\n\n')
        if true_labels[i] == 0:
            text.insert(END,str(all_data[i])+ ' Label Predicted as MAY BE\n\n')
            
    text.insert(END,"PHBAL Accuracy : "+str(phbal_acc))     

def graph():
    height = [sse_acc,phbal_acc]
    bars = ('Existing SSE Accuracy', 'Propose PHBAL Accuracy')
    y_pos = np.arange(len(bars))
    plt.bar(y_pos, height)
    plt.xticks(y_pos, bars)
    plt.show()   
    
font = ('times', 16, 'bold')
title = Label(main, text='Privacy-aware Personal Data Storage (P-PDS): Learning how to Protect User Privacy from External Applications')
title.config(bg='darkviolet', fg='gold')  
title.config(font=font)           
title.config(height=3, width=120)       
title.place(x=0,y=5)

font1 = ('times', 12, 'bold')
text=Text(main,height=20,width=150)
scroll=Scrollbar(text)
text.configure(yscrollcommand=scroll.set)
text.place(x=50,y=120)
text.config(font=font1)


font1 = ('times', 14, 'bold')
uploadButton = Button(main, text="Upload Health Care Label Dataset", command=uploadLabelData)
uploadButton.place(x=10,y=550)
uploadButton.config(font=font1)  

decomposeButton = Button(main, text="Upload Health Care Unlabel Dataset", command=uploadUnlabelData)
decomposeButton.place(x=350,y=550)
decomposeButton.config(font=font1) 

clusterButton = Button(main, text="Run Existing Semi Supervised Ensemble Algorithm", command=SSE)
clusterButton.place(x=720,y=550)
clusterButton.config(font=font1) 

weekButton = Button(main, text="Run Personalized History-Based Active Learning Algorithm (PHBAL)", command=PHBAL)
weekButton.place(x=10,y=600)
weekButton.config(font=font1) 

arimaButton = Button(main, text="Accuracy Graph", command=graph)
arimaButton.place(x=620,y=600)
arimaButton.config(font=font1)

exitButton = Button(main, text="Exit", command=exit)
exitButton.place(x=820,y=600)
exitButton.config(font=font1) 

main.config(bg='sea green')
main.mainloop()
